import tkinter as tk
from PIL import Image, ImageTk
from main import GobangGUI
import subprocess


class StartGameGUI:
    def __init__(self, ):
        self.root = tk.Tk()
        self.root.title("游戏库")

        # 加载背景图片
        self.background_image = Image.open("image/background.jpg") # 确保这个文件存在
        self.background_photo = ImageTk.PhotoImage(self.background_image)
        # 添加一个 Canvas 作为背景
        self.canvas = tk.Canvas(self.root, width=450, height=200)
        self.canvas.pack()
        # 加载背景图片
        image = Image.open("image/zhuye.jpg")  # 替换为你的背景图片文件名
        photo = ImageTk.PhotoImage(image)
        self.canvas.create_image(0, 0, anchor=tk.NW, image=photo)
        self.canvas.image = photo  # 保持对图片对象的引用，防止被垃圾回收

        # 创建标题
        title = tk.Label(self.root, text="其他游戏", font=("Arial", 24))
        title.pack(pady=20)

        # 创建开始游戏按钮
        start_button = tk.Button(self.root, text="五子棋", command=self.start_game)
        start_button.pack(pady=20)

        # 添加设置按钮
        self.settings_button = tk.Button(self.root, text="贪吃蛇", command=self.open_tcs)
        self.settings_button.pack()

        #退出游戏
        exit_button = tk.Button(self.root, text="退出游戏", command=self.root.withdraw)
        exit_button.pack(pady=20)

    def open_tcs(self):
        # 在这里实现打开设置界面的逻辑
        subprocess.Popen(["python", "tcs.py"])
        pass

    def start_game(self):
        # 关闭当前的Tkinter窗口
        self.root.destroy()
        # 使用subprocess模块执行main.py脚本
        #subprocess.Popen(["python", "main.py"])

        # 创建并显示游戏界面
        game = GobangGUI()
        game.run()

if __name__ == "__main__":
    start_gui = StartGameGUI()
    start_gui.root.mainloop()
