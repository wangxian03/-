import tkinter as tk
from tkinter import messagebox
import sys
import pygame
from PIL import Image, ImageTk
from datetime import datetime
import subprocess


class GobangGUI:
    def __init__(self, size=15):
        self.size = size
        self.player = 'black'
        self.board = [[' ' for _ in range(size)] for _ in range(size)]

        self.root = tk.Tk()
        self.root.title("五子棋")

        self.canvas = tk.Canvas(self.root, width=500, height=500)
        self.canvas.pack()

        self.load_background_image("image/background.jpg")  # 替换为你的背景图片文件名

        self.draw_board()
        self.canvas.bind("<Button-1>", self.on_click)

        # 初始化 pygame
        pygame.init()
        pygame.mixer.music.load("music/music.mp3")  # 替换为你的背景音乐文件名
        pygame.mixer.music.play(-1)  # 播放背景音乐，-1 表示循环播放

        self.time_label = tk.Label(self.root, text="", font=("Arial", 24))
        self.time_label.pack()
        self.update_time()

    def update_time(self):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.time_label.config(text=current_time)
        self.root.after(1000, self.update_time)  # 每隔一秒更新一次时间

    def load_background_image(self, filename):
        image = Image.open(filename)
        photo = ImageTk.PhotoImage(image)
        self.canvas.create_image(0, 0, anchor=tk.NW, image=photo)
        self.canvas.image = photo  # 保持对图片对象的引用，防止被垃圾回收

    def draw_board(self):
        gap = 30  # 调整每个线条之间的间隙
        for i in range(self.size):
            self.canvas.create_line(50, 50 + i * gap, 50 + (self.size - 1) * gap, 50 + i * gap)  # 横线
            self.canvas.create_line(50 + i * gap, 50, 50 + i * gap, 50 + (self.size - 1) * gap)  # 竖线

    def draw_piece(self, x, y):
        gap = 30  # 间隙
        if self.board[y][x] == ' ':
            self.board[y][x] = self.player
            color = "black" if self.player == 'black' else "white"  # 根据玩家设置棋子颜色
            piece_size = 12  # 调整棋子大小
            piece_x = 50 + x * gap - piece_size  # 根据格子位置计算棋子坐标
            piece_y = 50 + y * gap - piece_size  # 根据格子位置计算棋子坐标
            self.canvas.create_oval(piece_x, piece_y, piece_x + piece_size * 2, piece_y + piece_size * 2, fill=color)
            if self.check_win(x, y):  # 落子后检查胜利条件
                self.restart_game()
            self.player = 'white' if self.player == 'black' else 'black'  # 切换玩家为另一种颜色

    def restart_game(self):
        self.player = 'black'
        self.board = [[' ' for _ in range(self.size)] for _ in range(self.size)]
        self.canvas.delete("all")
        self.load_background_image("image/background.jpg")
        self.draw_board()
        self.canvas.bind("<Button-1>", self.on_click)

    def on_click(self, event):
        gap = 30  # 间隙
        x, y = (event.x - 50 + gap // 2) // gap, (event.y - 50 + gap // 2) // gap
        if 0 <= x < self.size and 0 <= y < self.size and self.board[y][x] == ' ':
            self.draw_piece(x, y)

    def check_win(self, x, y, ):
        directions = [(1, 0), (0, 1), (1, 1), (1, -1)]
        for dx, dy in directions:
            count = 1 + self.count_in_direction(x, y, dx, dy) + self.count_in_direction(x, y, -dx, -dy)
            if count >= 5:
                if messagebox.askyesno("游戏结束", f"{self.player.capitalize()} 玩家获胜! 是否返回主菜单?"):
                    self.restart_game()
                    return True
                else:
                    sys.exit()

        return False

    def count_in_direction(self, x, y, dx, dy):
        player = self.board[y][x]
        count = 0
        x, y = x + dx, y + dy
        while 0 <= x < self.size and 0 <= y < self.size and self.board[y][x] == player:
            count += 1
            x, y = x + dx, y + dy
        return count

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    game = GobangGUI()
    game.run()
